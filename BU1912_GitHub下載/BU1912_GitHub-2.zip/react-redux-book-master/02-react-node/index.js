require('babel-register');
require('./src/server.js');
