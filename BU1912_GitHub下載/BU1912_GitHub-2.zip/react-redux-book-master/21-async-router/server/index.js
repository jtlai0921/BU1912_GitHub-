__SERVER__ = true;
require('babel-register');
require('./server');
