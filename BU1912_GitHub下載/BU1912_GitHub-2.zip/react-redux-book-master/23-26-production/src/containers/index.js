export Main from './Main/Main';
export Home from './Home/Home';
export NotFound from './NotFound/NotFound';
export Counter from './Counter/Counter';
export Forms from './Forms/Forms';
export Statistic from './Statistic/Statistic';
export Login from './Login/Login';
