document.write(`<img src="${require('./Counter.png')}" alt="Counter"/>`);
