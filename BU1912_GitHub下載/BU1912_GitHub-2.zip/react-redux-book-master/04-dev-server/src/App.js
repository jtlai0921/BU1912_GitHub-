import React, { Component } from 'react';

// export default function App() {
//   return <h1>hello world</h1>;
// }
export default class App extends Component { // eslint-disable-line
  render() {
    // console.log('Source Map Testing');
    // throw new Error();
    return <h1>hello world</h1>;
  }
}
