import React from 'react';

export default function NotFound() {
  return (
    <div className="container">
      <h1>404!</h1>
      <p>您要找的页面不存在！</p>
    </div>
  );
}
