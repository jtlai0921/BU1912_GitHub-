# React Redux Heroku

[![Build Status](https://travis-ci.org/lewis617/react-redux-heroku.svg?branch=master)](https://travis-ci.org/lewis617/react-redux-heroku)

```sh
heroku login
heroku create <your-app-name>
heroku config:set NPM_CONFIG_PRODUCTION=false
git push heroku master
heroku open
```

